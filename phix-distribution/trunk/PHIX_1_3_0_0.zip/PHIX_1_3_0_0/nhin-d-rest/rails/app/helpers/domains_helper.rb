module DomainsHelper
end

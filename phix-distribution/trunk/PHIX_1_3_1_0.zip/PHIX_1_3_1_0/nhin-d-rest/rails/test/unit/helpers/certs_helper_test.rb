require 'test_helper'

class CertsHelperTest < ActionView::TestCase
end
